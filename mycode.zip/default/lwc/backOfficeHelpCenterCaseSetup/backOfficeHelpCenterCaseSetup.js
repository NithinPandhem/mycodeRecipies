import { LightningElement, wire } from "lwc";
import getHelpCenterMappings from "@salesforce/apex/HelpCenterCaseMappingController.getHelpCenterMappings";
import getCountryPicklist from "@salesforce/apex/HelpCenterCaseMappingController.getCountryPicklist";
import getPlatformPicklist from "@salesforce/apex/HelpCenterCaseMappingController.getPlatformPicklist";
import getQueueNameList from "@salesforce/apex/HelpCenterCaseMappingController.getQueueNameList";
import upsertHelpcenterCaseMapping from "@salesforce/apex/HelpCenterCaseMappingController.upsertHelpcenterCaseMapping";
import getRecTypeDevNameMap from "@salesforce/apex/HelpCenterCaseMappingController.getRecTypeDevNameMap";
import isEnabledForUser from "@salesforce/apex/HelpCenterCaseMappingController.isEnabledForUser";
import getQueueByEntityCountryMap from "@salesforce/apex/HelpCenterCaseMappingController.getQueueByEntityCountryMap";
import getRtByEntityCountryMap from "@salesforce/apex/HelpCenterCaseMappingController.getRtByEntityCountryMap";


import { ShowToastEvent } from "lightning/platformShowToastEvent";
import { getObjectInfo } from "lightning/uiObjectInfoApi";
import { refreshApex } from "@salesforce/apex";
import { getPicklistValues } from 'lightning/uiObjectInfoApi';

import CASE_OBJECT from "@salesforce/schema/Case";
import FIELD_CASE_REASON_LEVEL_1 from '@salesforce/schema/Case.Case_Reason_Level_1__c';
import FIELD_CASE_REASON_LEVEL_2 from '@salesforce/schema/Case.Case_Reason_Level_2__c';
import FIELD_CASE_REASON_LEVEL_3 from '@salesforce/schema/Case.Case_Reason_Level_3__c';
import FIELD_TYPE from '@salesforce/schema/Case.Type';
import FIELD_CASE_REASON from '@salesforce/schema/Case.Case_Reason__c';

export default class backOfficeHelpCenterCaseSetup extends LightningElement {
    FIELD_CASE_REASON_LEVEL_1_VALUES;
    FIELD_CASE_REASON_LEVEL_2_VALUES;
    FIELD_CASE_REASON_LEVEL_3_VALUES;
    FIELD_TYPE_VALUES;
    FIELD_CASE_REASON_VALUES;

    showSpinner = false;
    showEdit = false;

    currentRecordValue; // current state of form

    // the edit form
    //////////////////
    mappingId;
    mappingRecordTypeId;
    mappingPlatform;
    mappingCountry;
    mappingCcr1;
    mappingCcr2;
    mappingCcr3;
    mappingType;
    mappingCaseReason;
    mappingQueue;

    // this is to filter the hcmList (getter)
    ////////////////
    countryPicklist_;
    platformPicklist_;
    platformSelected;
    countrySelected;

    // picklist values
    @wire(getPicklistValues, { recordTypeId: '$mappingRecordTypeId', fieldApiName: FIELD_CASE_REASON_LEVEL_1 }) n113({error, data}) {
        if (data) this.FIELD_CASE_REASON_LEVEL_1_VALUES = data;
    };
    @wire(getPicklistValues, { recordTypeId: '$mappingRecordTypeId', fieldApiName: FIELD_CASE_REASON_LEVEL_2 }) dc24({error, data}) {
        if (data) this.FIELD_CASE_REASON_LEVEL_2_VALUES = data;
    };
    @wire(getPicklistValues, { recordTypeId: '$mappingRecordTypeId', fieldApiName: FIELD_CASE_REASON_LEVEL_3 }) hgf3({error, data}) {
        if (data) this.FIELD_CASE_REASON_LEVEL_3_VALUES = data;
    };
    @wire(getPicklistValues, { recordTypeId: '$mappingRecordTypeId', fieldApiName: FIELD_TYPE }) zz9j({error, data}) {
        if (data) this.FIELD_TYPE_VALUES = data;
    };
    @wire(getPicklistValues, { recordTypeId: '$mappingRecordTypeId', fieldApiName: FIELD_CASE_REASON }) zz9x({error, data}) {
        if (data) this.FIELD_CASE_REASON_VALUES = data;
    };
    @wire(getObjectInfo, { objectApiName: CASE_OBJECT }) caseObjectInfo;

    @wire(isEnabledForUser) isEnabled_;
    @wire(getRecTypeDevNameMap) recTypeByDevNameMap;
    @wire(getHelpCenterMappings) hcmList_;
    @wire(getQueueNameList) queueNameList;
    @wire(getQueueByEntityCountryMap) queueByEntityCountryMap;
    @wire(getRtByEntityCountryMap) rtByEntityCountryMap;

    @wire(getCountryPicklist) getCountryPicklistWire({error, data}) {
        if (data) {
            this.countryPicklist_ = this.sortMe(data);
            this.countrySelected = this.countryPicklist_[0].value;
        } else if (error) {
            console.log('## getCountryPicklist error', error);
        }
    };

    @wire(getPlatformPicklist) getPlatformPicklistWire({error, data}) {
        if (data) {
            this.platformPicklist_ = this.sortMe(data);
            this.platformSelected = this.platformPicklist_[0].value;
        } else if (error) {
            console.log('## getPlatformPicklist error', error);
        }
    };

    @wire(getCountryPicklist) getCountryPicklistWire({error, data}) {
        if (data) {
            this.countryPicklist_ = this.sortMe(data);
            this.countrySelected = this.countryPicklist_[0].value;
        } else if (error) {
            console.log('## getCountryPicklist error', error);
        }
    };

    @wire(getPlatformPicklist) getPlatformPicklistWire({error, data}) {
        if (data) {
            this.platformPicklist_ = this.sortMe(data);
            this.platformSelected = this.platformPicklist_[0].value;
        } else if (error) {
            console.log('## getPlatformPicklist error', error);
        }
    };

    // getters for UI
    /////////////////////////////////

    get isEnabled() { // looks for SF_Service_Back_Office_Manage_Help_Center_Mapping custom permisssion
        if (this.isEnabled_ === undefined) return false;
        return this.isEnabled_.data;
    }

    get hcmList() {
        if (this.hcmList_ === undefined || this.hcmList_.data === undefined) return [];

        let filteredHclList = this.hcmList_.data;
        if (this.countrySelected != null) {
            filteredHclList = filteredHclList.filter(el => el.Country__c === this.countrySelected);
        }
        if (this.platformSelected != null) {
            filteredHclList = filteredHclList.filter(el => el.Platform__c === this.platformSelected);
        }
        return filteredHclList;
    }

    get platformOptions() {
        if (this.platformPicklist_ === undefined) return [];
        return this.platformPicklist_;
    }

    get countryOptions() {
        if (this.countryPicklist_ === undefined) return [];
        return this.countryPicklist_;
    }

    // values for the Queue picklist
    // filtered by the available Queues for the selected Entity (this.mappingPlatform) and Country (this.mappingCountry)
    get queueOptions() {
        if (!this.queueNameList || !this.queueNameList.data) return [];
        if (!this.queueByEntityCountryMap || !this.queueByEntityCountryMap.data) return [];
        if (!this.mappingPlatform || !this.mappingCountry) return [];
        
        let entityCountryKey = this.mappingPlatform + '_' + this.mappingCountry;
        if (!this.queueByEntityCountryMap.data[entityCountryKey]) return []; // return anything if values set for this entityCountryKey

        let qList = this.queueNameList.data
            .filter(el => this.queueByEntityCountryMap.data[entityCountryKey].includes(el)) // filter out everything which is not in entityCountryKey business rule
            .map(el => {
                return { value: el, label: el };
            });
        return this.sortMe(qList);
    }

    get caseReasonOptions() { return this.fieldOptionsMapper(this.FIELD_CASE_REASON_VALUES); }
    get caseReasonLevel1Options() { return this.fieldOptionsMapper(this.FIELD_CASE_REASON_LEVEL_1_VALUES); }
    get caseReasonLevel2Options() { return this.fieldOptionsMapper(this.FIELD_CASE_REASON_LEVEL_2_VALUES); }
    get caseReasonLevel3Options() { return this.fieldOptionsMapper(this.FIELD_CASE_REASON_LEVEL_3_VALUES); }
    get typeOptions() { return this.fieldOptionsMapper(this.FIELD_TYPE_VALUES); }

    // returns the available RTs for the given platform-country combination
    get caseRecordTypePicklistOptions() {
        if (!this.caseObjectInfo 
            || !this.caseObjectInfo.data 
            || !this.rtByEntityCountryMap 
            || !this.rtByEntityCountryMap.data
            || !this.mappingPlatform
            || !this.mappingCountry
        ) {
            return [];
        }

        let entityCountryKey = this.mappingPlatform + '_' + this.mappingCountry;
        if (!this.rtByEntityCountryMap.data[entityCountryKey]) return []; // return anything if values set for this entityCountryKey

        let pickListList = Object.keys(this.caseObjectInfo.data.recordTypeInfos).map((key) => {
                return {
                    value: this.caseObjectInfo.data.recordTypeInfos[key].recordTypeId,
                    label: this.caseObjectInfo.data.recordTypeInfos[key].name,
                };
            }).filter(el => this.rtByEntityCountryMap.data[entityCountryKey].includes(el.value));
        return this.sortMe(pickListList, "label");
    }

    get isNewRecord() {
        return this.mappingId == undefined;
    }

    // after a row is selected, this one populates the form
    ///////////////////////////
    populateEditRecordForm(
        id,
        country,
        platform,
        type,
        ccr1,
        ccr2,
        ccr3,
        caseReason,
        recordTypeDeveloperName,
        queueName
    ) {
        this.mappingId = id;
        this.mappingCountry = country;
        this.mappingPlatform = platform;
        this.mappingType = type;
        this.mappingRecordTypeId = this.recTypeByDevNameMap?.data[recordTypeDeveloperName];
        this.mappingQueue = queueName;
        this.mappingCcr1 = ccr1;
        this.mappingCcr2 = ccr2;
        this.mappingCcr3 = ccr3;
        this.mappingCaseReason = caseReason;        
        this.showEdit = true;
    }

    // cleans up the edit form
    /////////////////////////
    cleanCaseMappingRecord() {
        this.mappingId = undefined;
        this.mappingRecordTypeId = undefined;
        this.mappingPlatform = undefined;
        this.mappingCountry = undefined;
        this.mappingType = undefined;
        this.mappingCcr1 = undefined;
        this.mappingCcr2 = undefined;
        this.mappingCcr3 = undefined;
        this.mappingCaseReason = undefined;
        this.mappingQueue = undefined;
    }

    // save to DB
    ////////////////////////////
    saveCaseMappingRecord() {
        upsertHelpcenterCaseMapping(this.currentRecordValue)
            .then(r => {
                this.cleanCaseMappingRecord();
                refreshApex(this.hcmList_);
                this.showSpinner = false;
                this.showToast('Success', 'Record saved to database.');
            }).catch(error => {
                console.log('### error', error);
                this.showToast('It\'s an error!', error.body.message, 'error');
            });
    }

    showToast(title, message, variant = 'success') {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant
        });
        this.dispatchEvent(event);
    }


    // UI binding methods
    /////////////////////////


    // the clicks
    //////////////////////
    onRecordEditClick(ev) {

        const recordId = ev.target.value;
        let myRecord = this.hcmList.find((rec) => rec.Id === recordId);

        this.populateEditRecordForm(
            myRecord.Id,
            myRecord.Country__c,
            myRecord.Platform__c,
            myRecord.Type__c,
            myRecord.Case_Reason_Level_1__c,
            myRecord.Case_Reason_Level_2__c,
            myRecord.Case_Reason_Level_3__c,
            myRecord.Case_Reason__c,
            myRecord.RecordType__c,
            myRecord.Owner__c
        );
    }

    onSaveClicked() {
        this.showEdit = false;
        this.showSpinner = true;
        this.saveCaseMappingRecord();
    }

    hideEditClicked() {
        this.showEdit = false;
    }

    onNewMappingClicked() {
        this.cleanCaseMappingRecord();
        this.mappingCountry = this.countrySelected;
        this.mappingPlatform = this.platformSelected;
        this.showEdit = true;
    }

    // the  picklist changing
    /////////////
    handlePlatformFilterChange(ev) {
        this.platformSelected = ev.target.value;
    }

    handleCountryFilerChange(ev) {
        this.countrySelected = ev.target.value;
    }

    // when any field changed on edit form
    onFieldChange() {
        this.mappingRecordTypeId = this.template.querySelector(".mapping-record-type-id").value;
        this.mappingPlatform = this.template.querySelector(".mapping-platform").value;
        this.mappingCountry = this.template.querySelector(".mapping-country").value;
        this.mappingCcr1 = this.template.querySelector(".mapping-case-reason-level-1").value;
        this.mappingCcr2 = this.template.querySelector(".mapping-case-reason-level-2").value;
        this.mappingCcr3 = this.template.querySelector(".mapping-case-reason-level-3").value;
        this.mappingType = this.template.querySelector(".mapping-type").value;   
        this.mappingCaseReason = this.template.querySelector(".mapping-case-reason").value;
        this.mappingQueue = this.template.querySelector(".mapping-queue").value;

        this.currentRecordValue = {
            id: this.mappingId,
            country: this.mappingCountry,
            platform: this.mappingPlatform,
            ccr1: this.mappingCcr1,
            ccr2: this.mappingCcr2,
            ccr3: this.mappingCcr3,
            type: this.mappingType,
            caseReason: this.mappingCaseReason,
            recordTypeId: this.mappingRecordTypeId,
            queue: this.mappingQueue
        }
        console.log('## current state: ', this.currentRecordValue);
    }  
    
    // helpers
    ////////////
    sortMe(list, prop="label") {
        let toSort = JSON.parse(JSON.stringify(list));
        toSort.sort((a, b) => (a[prop] > b[prop]) ? 1 : -1);
        return toSort;
    }
    
    fieldOptionsMapper (field) {
        if (!field || !field.values) return [];
        return field.values;
    }

}
