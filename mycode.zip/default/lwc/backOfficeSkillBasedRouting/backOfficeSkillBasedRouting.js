import { LightningElement, wire, track } from 'lwc';
import getSkillRouting from '@salesforce/apex/BackOfficeSkillAuraController.getSkillRouting';
import saveSkillRouting from '@salesforce/apex/BackOfficeSkillAuraController.saveSkillRouting';
import getAllSkills from '@salesforce/apex/BackOfficeSkillAuraController.getAllSkills';
import getCasePicklistValues from '@salesforce/apex/BackOfficeSkillAuraController.getCasePicklistValues';
import getCountryNames from '@salesforce/apex/BackOfficeSkillAuraController.getCountryNames';
import getPlatformNames from '@salesforce/apex/BackOfficeSkillAuraController.getPlatformNames';
import isEnabledForUser from '@salesforce/apex/BackOfficeSkillAuraController.isEnabledForUser';
import CASE_OBJECT from '@salesforce/schema/Case';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent'

export default class backOfficeSkillBasedRouting extends LightningElement {

    @track routing;
    platform;
    country;
    countryNames;
    platformNames;
    selectedPreset;
    selectedDimension;
    showNewSkillModal = false;
    showNewDimensionModal = false;
    showNewValueModel = false;
    showSpinner = false;
    isRoutingChanged = false; // true if there was a change AND its not saved to database

    skillsComboSelected = [];
    currentPicklistValues;


    // Wirings
    ///////////////////////////////

    // the routing database call; wrapped in allRouting getter
    @wire(getSkillRouting, { platform: '$platform', country: '$country' })
    function(r) {
        if (r.data) {
            this.routing = JSON.parse(r.data);
        } else if (!r.error) {
            this.routing = { presetList: [] };
        }
    }

    @wire(isEnabledForUser) isEnabled_;
    @wire(getAllSkills) allSkills;
    @wire(getObjectInfo, { objectApiName: CASE_OBJECT }) caseObjectInfo;
    @wire(getCountryNames) getCountryNamesWire({error, data}) {
        if (data) {
            this.countryNames = data;
            this.country = this.countryNames[0].value;
        } else if (error) {
            console.log('## getCountryNames error', error);
        }
    }
    @wire(getPlatformNames) getPlatformNamesWire({error, data}) {
        if (data) {
            this.platformNames = data;
            this.platform = this.platformNames[0].value;
        } else if (error) {
            console.log('## getPlatformNames error', error);
        }
    }

    // Getters
    ///////////////////////

    get isEnabled() { // looks for SF_Service_Back_Office_Manage_Skills custom permisssion
        if (this.isEnabled_ === undefined) return false;
        return this.isEnabled_.data;
    }

    // this goes to the HTML, adding some extra properties to know what was clicked
    get allRouting() {
        if (!this.routing) {
            return undefined;
        }

        let routingWithExtraProps = JSON.parse(JSON.stringify(this.routing)); // cloning, bc we dont want to have the UI-related properties in the business config
        // mapping the executionOrderAndDimension property -- this is for catching the click on the dimension 'add new value' button
        routingWithExtraProps.presetList = routingWithExtraProps.presetList.map(preset => {
            preset.dimensionList = preset.dimensionList.map(dim => {
                dim.executionOrderAndDimension = preset.executionOrder + ';' + dim.fieldName;
                
                dim.emptyFieldValueList = false;
                if (dim.fieldValueList == null || dim.fieldValueList.length == 0) {
                    dim.emptyFieldValueList = true;
                }

                return dim;
            });
            
            // empty skill property 
            preset.emptySkillList = false;
            if (preset.skillList == undefined || preset.skillList.length == 0) {
                preset.emptySkillList = true;
            } else {
                // adding the skill label as a property
                preset.skillList = preset.skillList.map(skill => {
                    skill.skillLabel = this.getSkillLabel(skill.skillName);
                    return skill;
                });
            }

            //empty dimension propery
            preset.emptyDimensionList = false;
            if (preset.dimensionList == undefined || preset.dimensionList.length == 0) {
                preset.emptyDimensionList = true;
            }

            return preset;
        });
        return routingWithExtraProps;
    }

    get emptyRouting() {
        return !this.allRouting || !this.allRouting.presetList || this.allRouting.presetList.length == 0;
    }

    get getAllSkills() {
        if (this.allSkills.data === undefined) return [];

        return this.allSkills.data.map(skill => {
            return {
                label: skill.MasterLabel,
                value: skill.DeveloperName
            };
        });
    }

    get countryList() {
        if (this.countryNames) {
            return this.countryNames;
        } else {
            return [];
        }        
    }

    get platformList() {
        if (this.platformNames) {
            return this.platformNames;
        } else {
            return [];
        }
    }

    // this is used by the 'add new dimension'. Currently returns only picklist-type fields
    get getAllFields() {
        if (this.caseObjectInfo.data) {
            return Object.keys(this.caseObjectInfo.data.fields)
                .filter(el => {
                    return this.caseObjectInfo.data.fields[el].dataType == 'Picklist';
                })
                .map(el => {
                    return { label: el, value: el };
                });
        }
        return [];
    }

    get isSaveDisabled() {
        return !this.isRoutingChanged;
    }

    // Functionality -- here nothing is called directly from HTML
    /////////////////////////

    // sets the skill for the selected preset
    // currently all skills are added with the weight of 5
    addSkills() {
        if (this.selectedPreset == undefined || !this.skillsComboSelected) return;

        this.routing.presetList = this.routing.presetList.map(preset => {
            if (preset.executionOrder == this.selectedPreset) {
                preset.skillList = this.skillsComboSelected.map(skill => {
                    return { skillName: skill, skillLevel: 5 };
                });
            }
            return preset;
        });
        this.isRoutingChanged = true;
    }

    // adds a field (dimension) for the selected preset. Field name comes from parameter.
    addField(selectedField) {

        if (this.selectedPreset == undefined || !selectedField) {
            return;
        }

        this.routing.presetList = this.routing.presetList.map(preset => {
            if (this.selectedPreset == preset.executionOrder) {
                preset.dimensionList.push(
                    { fieldName: selectedField, fieldValueList: [] }
                )
            }
            return preset;
        });
        this.isRoutingChanged = true;
    }

    // sets the values on the selected dimension. Values come from valuesComboSelected.
    addValues() {
        if (this.selectedPreset == undefined || !this.selectedDimension) return;

        this.routing.presetList = this.routing.presetList.map(preset => {
            if (this.selectedPreset == preset.executionOrder) {
                preset.dimensionList = preset.dimensionList.map(dim => {
                    if (dim.fieldName == this.selectedDimension) {
                        dim.fieldValueList = this.valuesComboSelected.sort();
                    }
                    return dim;
                });
            }
            return preset;
        });
        this.isRoutingChanged = true;
    }

    // saves the routing to the business config, via Apex
    saveToDb() {
        saveSkillRouting({
            platform: this.platform,
            country: this.country,
            routingValue: JSON.stringify(this.routing, null, 4)
        })
            .then(r => {
                this.showToast('Saved to Backend.');
                this.isRoutingChanged = false;
            })
            .catch(error => {
                console.log('### error', error);
                this.showToast('It\'s an error!', error.body.message, 'error');
            });
    }

    // removes the selected preset
    deletePreset() {
        this.routing.presetList = this.routing.presetList.filter(preset => preset.executionOrder != this.selectedPreset);
        this.isRoutingChanged = true;
    }

    // adds a preset, to the end of the preset list
    addNewPreset() {
        // this is here to figure out what is the last executionOrder number. The new preset has +1
        let exOrd = 5;
        if (this.routing.presetList.length > 0) {
            exOrd = this.routing.presetList[this.routing.presetList.length - 1].executionOrder + 1;
            if (!exOrd) {
                exOrd = 5;
            }
        }
        this.routing.presetList.push({
            executionOrder: exOrd,
            dimensionList: [],
            skillList: []
        });
        this.isRoutingChanged = true;
    }

    // removes a dimension from a selected preset
    deleteDimension(executionOrder, dimension) {
        this.routing.presetList = this.routing.presetList.map(preset => {
            if (preset.executionOrder == executionOrder) {
                preset.dimensionList = preset.dimensionList.filter(dim => dim.fieldName != dimension); // so we keep all but the delete dimension
            }
            return preset;
        });
        this.isRoutingChanged = true;
    }

    showToast(title, message, variant = 'success') {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant
        });
        this.dispatchEvent(event);
    }

    // maps a skill label to a skill (developer) name. Used on the skill badges
    getSkillLabel(skillName) {
        return this.getAllSkills.find(skill => skill.value == skillName)?.label;
    }

    // All the button bindings
    ////////////////////////////////////////

    onNewSkillClicked(ev) {
        this.selectedPreset = ev.target.value;
        this.skillsComboSelected = this.routing.presetList
            .find(preset => preset.executionOrder == this.selectedPreset)
            .skillList.map(skill => skill.skillName);

        this.showNewSkillModal = true;
    }

    onNewDimensionClicked(ev) {
        this.selectedPreset = ev.target.value;
        this.showNewDimensionModal = true;
    }

    onDeletePresetClicked(ev) {
        this.selectedPreset = ev.target.value;
        this.deletePreset();
    }

    onNewPresetClicked(ev) {
        this.addNewPreset();
    }

    // before popping the modal, gets all the possible picklist values to show as options
    onSetValuesClicked(ev) {
        let exOrderAndDimension = ev.target.value;
        const [exORder, dim] = exOrderAndDimension.split(';');
        if (!exORder || !dim) return;

        this.selectedPreset = exORder;
        this.selectedDimension = dim;

        // those are the _already selected_ values; options come in the next apex call
        this.valuesComboSelected = this.routing.presetList.find(preset => preset.executionOrder == exORder)
            .dimensionList.find(dimension => dimension.fieldName == dim)
            .fieldValueList;

        // get the options for the select values compo (apex call, picklist values come from server)
        this.showSpinner = true;
        getCasePicklistValues({ fieldName: this.selectedDimension })
            .then(picklistValues => {
                this.currentPicklistValues = picklistValues;

                // show the modal and hide the spinner once the available values arrived;
                this.showSpinner = false;
                this.showNewValueModel = true;

            }).catch(error => {
                console.log('## getCasePicklistValues error', error);
            })
    }
     
    onDeleteDimensionClicked(ev) {
        let exOrderAndDimension = ev.target.value;
        const [exORder, dim] = exOrderAndDimension.split(';');
        if (!exORder || !dim) return;
        this.deleteDimension(exORder, dim);
    }    

    onSaveClicked(ev) {
        this.saveToDb();
    }

    // Modal button bindings
    ////////////////////////

    onAddDimensionClicked(ev) {
        let selector = this.template.querySelector('.field-selector');
        let selectedField = selector.value;
        this.showNewDimensionModal = false;
        this.addField(selectedField);
    }

    onHideNewDimensionClicked(ev) {
        this.showNewDimensionModal = false;
    }

    onSaveValuesClicked(ev) {
        this.showNewValueModel = false;
        this.addValues();
    }

    onHideNewValueClicked(ev) {
        this.showNewValueModel = false;
    }

    onAddSkillClicked(ev) {
        this.showNewSkillModal = false;
        this.addSkills();
    }

    onHideNewSkillModalClicked(ev) {
        this.showNewSkillModal = false;
    }

    // modal change events
    ////////////////////

    onSkillSelectorChanged(ev) {
        let currentSkillsSelected = ev.detail.value;

        this.skillsComboSelected = [];
        Object.keys(currentSkillsSelected).forEach(key => {
            this.skillsComboSelected.push(currentSkillsSelected[key]);
        });
    }

    onValueSelectorChanged(ev) {
        let currentValuesSelected = ev.detail.value;

        this.valuesComboSelected = [];
        Object.keys(currentValuesSelected).forEach(key => {
            this.valuesComboSelected.push(currentValuesSelected[key]);
        });
    }

    // other change events
    /////////////////////////////

    onCountryChange(ev) {
        let country = ev.detail.value;
        if (!country) return;
        this.country = country;
    }

    onPlatformChange(ev) {
        let platform = ev.detail.value;
        if (!platform) return;
        this.platform = platform;
    }
}